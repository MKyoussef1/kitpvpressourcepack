# KitBattles HUD Resource Pack v5
## Character Map

### Keybind Keys
| Char   | Texture                  |
|--------|--------------------------|
| \uE100 | F  (normal)              |
| \uE101 | F  (active / pressed)    |
| \uE102 | Q  (normal)              |
| \uE103 | Q  (active / pressed)    |
| \uE104 | Shift                    |
| \uE105 | ESC                      |

### Number Keys
| Key | Normal  | Active (pressed) |
|-----|---------|-----------------|
| 1   | \uE110  | \uE120          |
| 2   | \uE111  | \uE121          |
| 3   | \uE112  | \uE122          |
| 4   | \uE113  | \uE123          |
| 5   | \uE114  | \uE124          |
| 6   | \uE115  | \uE125          |
| 7   | \uE116  | \uE126          |
| 8   | \uE117  | \uE127          |
| 9   | \uE118  | \uE128          |

### Icons
| Char   | Icon        |
|--------|-------------|
| \uE130 | LMB (left click)  |
| \uE131 | RMB (right click) |
| \uE132 | Plus / confirm    |
| \uE133 | X / cancel        |
| \uE134 | Arrow             |

### Cooldown Bars (0% → 100%, red → green)
| Char   | Fill  |
|--------|-------|
| \uE140 | 0%   |
| \uE141 | 10%  |
| ...    | ...  |
| \uE14A | 100% |

### Vertical Offset (push HUD line down)
| Char   | Offset  | Best for              |
|--------|---------|-----------------------|
| \uE300 | -40px   | GUI scale 3, 1080p    |
| \uE301 | -70px   | GUI scale 2, 1080p    |
| \uE302 | -100px  | GUI scale 1           |
| \uE303 | -128px  | Maximum               |

### Cursor Movement (negative = left, positive = right)
\uE200=-1  \uE201=-2  \uE202=-4  \uE203=-8  \uE204=-16  \uE205=-32  \uE206=-64  \uE207=-128  \uE208=-256
\uE210=+1  \uE211=+2  \uE212=+4  \uE213=+8  \uE214=+16  \uE215=+32

### Font name for plugin
`kitbattles:hud`

### Bottom-left placement example
```java
String hud = "\uE301"   // push line to bottom
           + "\uE208"   // rewind -256px
           + "\uE208"   // rewind -256px again
           + "\uE214"   // nudge right +16px (left margin)
           + "\uE100"   // F key icon
           + "\uE212"   // +4px gap
           + "\uE144";  // cooldown bar at 40%
player.sendActionBar(hud);
```
